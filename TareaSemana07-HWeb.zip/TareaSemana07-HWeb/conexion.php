<?php

    $cn = mysql_connect("localhost", "root", "0024");
    mysql_select_db("bd_ciisi2022", $cn);

    

?>